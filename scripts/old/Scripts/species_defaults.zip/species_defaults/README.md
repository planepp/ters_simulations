Four defaults are provided:

- `light`: Updates compared to `default_2010`: 
    Be(+3p), Al-Cl(+4f), K(radial_base,cut_pot), Co-Ni(+ionic 4p), Ga-Br(+4f), 
    Kr-Sr(`radial_base`,`cut_pot`), In-I(+4f), Xe-Ba, Rn(`radial_base`,`cut_pot`)
- `intermediate`: now, complete set of elements 1-86. Derived from the `tight` 
    species defaults, however, with focus to provide good but still affordable 
    accuracy for hybrid DFT calculations.
- `tight`: Changes compared to `default_2010`: 
    Mn(+3d function), Zn-Kr(+5g function), In-Xe(+5g function)
- `really_tight`: Changes compared to `default_2010`: 
    Zn-Kr(+5g function), In-Xe(+5g function) 

The updates of the `light`, `tight`, and `really_tight` defaults are the results of 
a careful analysis of the Delta-Code DFT (DCDFT) Test (71 solids). So the updates should
improve the accuracy of an element for the material class (insulator or metal) 
that is present in the DCDFT Test (e.g., the Be crystal is metallic in the test, but may
be an ion for some other systems).


## How to use `light`, `tight`, and `really_tight`

Regarding `light`, `tight`, and `really_tight`, we here repeat 
only that many DFT-LDA/GGA production tasks (e.g.,
pre-relaxation) can and should first be done at the
`light` level, while the `tight` level then allow a
more detailed verification / post-convergence of
all results. Finally, `really_tight` is provided in
case stringent convergence tests are required - for
example, when trying out larger basis sets (`tier 3`, 
`tier 4` etc.). Note that production
calculations should not simply be run at at the
`really_tight` level out of precaution. Of course,
there may be good reasons to use modified
`really_tight` for specific tasks where convergence is
more subtle and requires checking by hand, such as
in MP2, GW, RPA, i.e., the methods that involve the
unoccupied spectrum explicitly.

The references for these standard FHI-aims basis sets is

> Volker Blum, Ralf Gehrke, Felix Hanke, Paula Havu,
> Ville Havu, Xinguo Ren, Karsten Reuter, and Matthias Scheffler,
> 'Ab Initio Molecular Simulations with Numeric Atom-Centered Orbitals',
> Computer Physics Communications 180, 2175-2196 (2009)

## The `intermediate` settings

`intermediate` settings, where available, are derived from `tight`
settings, but lightened with the specific goal of providing still
reliable but affordable accuracy for production calculations of very
large systems with hybrid density functionals.

For hybrid functionals, the dominant memory and CPU time requirements
are associated with the number of basis functions per atom. These can
quickly become overwhelming in practical calculations, especially when
gradients and stress tensors for bulk materials are required.

In contrast, the integration grids or Hartree potential evaluation,
which are important performance parameters in semilocal DFT, play a
relatively much smaller role for hybrid functionals.

Thus, in the `intermediate` settings, the number of radial functions
is reduced to a level that will still be acceptable for many tasks,
but much less expensive than the full "tight" settings. 

`intermediate` settings can, of course, equally well be used for
semilocal DFT. Here, too, some applications will not need the full
accuracy of `tight` settings. As an example, bulk oxides may not
necessarily need the full accuracy of tier 2 (which is designed to
handle the subtleties of weakly bonded systems, like intermolecular
bonds). For these, `intermediate` settings for O may well suffice for
many applications.

A description of what the `for_aux` keyword, used in these defaults,
does, can be found in New J. Phys. 17, 093020 (2015). 

The `for_aux` keyword has no effect for semilocal density functionals.




